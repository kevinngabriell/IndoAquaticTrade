<!-- resources/views/home.blade.php -->



<?php $__env->startSection('content'); ?>
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Blog</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li ><a href="<?php echo e(url('/blogs')); ?>">Blog</a> </li>
            <li><?php echo e($blog->title); ?></li>
          </ol>
        </div>

      </div>
    </section>

    <section class="inner-page">
      <div class="container">
        <div class="py-12">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <img src="<?php echo e(asset('storage/' . $blog->image_blog)); ?>" class="img-fluid" width="200" alt="Blog Image">
                </div>
                <?php echo $blog->content; ?>

            </div>
          
      </div>
      
      </div>
    </section>

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/aquatic/blog_detail.blade.php ENDPATH**/ ?>