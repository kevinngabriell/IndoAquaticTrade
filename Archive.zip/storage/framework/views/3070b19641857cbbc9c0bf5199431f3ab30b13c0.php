<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Edit Profil')); ?>

      </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-5">
            <form action="<?php echo e(route('profil.update', $profil->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>
              <div class="w-full">
                <div class="sejarah">
                  <p>ABOUT US</p>
                  <textarea name="sejarah" class="w-full h-36"><?php echo e($profil->sejarah); ?></textarea>
                </div>
                <div class="visi_misi mt-5">
                  <p>VISION</p>
                  <textarea name="visi_misi" class="w-full h-36"><?php echo e($profil->visi_misi); ?></textarea>
                </div>
                <div class="profil mt-5">
                  <p>MISSION</p>
                  <textarea name="profil" class="w-full h-36"><?php echo e($profil->profil); ?></textarea>
                </div>
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" type="submit">
                  Update
                </button>
              </div>
            </form>
          </div>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/profil/edit.blade.php ENDPATH**/ ?>