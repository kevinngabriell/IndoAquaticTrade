<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Data Hero')); ?>

      </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-5">
              <div class="p-5">
                  <table class="table-auto w-full mt-5">
                      <tr>
                          <th class="border px-4 py-2" width="30%">Title</th>
                          <th class="border px-4 py-2" width="60%">Description</th>
                          <th class="border px-4 py-2" width="60%">Why Us</th>
                          <th class="border px-4 py-2" width="10%">Aksi</th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $hero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                              <td class="border px-4 py-2"><?php echo e($item->title); ?></td>
                              <td class="border px-4 py-2"><?php echo e($item->description); ?></td>
                              <td class="border px-4 py-2"><?php echo e($item->why_us); ?></td>
                              <td class="border px-4 py-2 justify-between">
                                  <a href="<?php echo e(route('hero.edit', $item->id)); ?>" class="py-1 px-4 rounded-md bg-yellow-400">Edit</a>
                              </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr >
                              <td class="border px-4 py-2 text-center" colspan="4">Tidak ada data</td>
                          </tr>
                        <?php endif; ?>
                  </table>
              </div>
          </div>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/hero/index.blade.php ENDPATH**/ ?>