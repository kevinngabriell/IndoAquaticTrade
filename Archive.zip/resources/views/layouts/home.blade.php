<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $about->name }} - {{ $about->sub }}</title>
    <!-- Tambahkan stylesheet atau CDN apapun yang Anda perlukan -->
    <meta content="{{ $about->description }}" name="description">
    <meta content="{{ $about->keywords }}" name="keywords">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Favicons -->
    <link href="{{ asset($about->favicon) }}" rel="icon">
    <link href="{{ asset($about->favicon) }}" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="{{ asset('themeaqua/assets/vendor/animate.css/animate.min.css') }}" rel="stylesheet">
<link href="{{ asset('themeaqua/assets/vendor/aos/aos.css') }}" rel="stylesheet">
<link href="{{ asset('themeaqua/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('themeaqua/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
<link href="{{ asset('themeaqua/assets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
<link href="{{ asset('themeaqua/assets/vendor/glightbox/css/glightbox.min.css') }}" rel="stylesheet">
<link href="{{ asset('themeaqua/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="{{ asset('themeaqua/assets/css/style.css') }}" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <!-- =======================================================
    * Template Name: Restaurantly - v3.1.0
    * Template URL: https://bootstrapmade.com/restaurantly-restaurant-template/
    * Author: BootstrapMade.com
    * License: https://bootstrapmade.com/license/
    ======================================================== -->
    
</head>
<body>
  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-center justify-content-md-between">

      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-phone d-flex align-items-center"><span>{{ $about->phone }}</span></i>
        <i class="bi bi-clock d-flex align-items-center ms-4"><span> {{ $about->email }}</span></i>
      </div>

      {{-- <div class="languages d-none d-md-flex align-items-center">
        <ul>
          <li>En</li>
          <li><a href="#">De</a></li>
        </ul>
      </div> --}}
    </div>
  </div>

  <!-- ======= Header ======= -->
  
  <header id="header" class="fixed-top d-flex align-items-cente">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-lg-between">
      <a href="{{ url('/') }}" class="logo me-auto me-lg-0" >
        <img class="Sirv" src="{{ asset($about->logo) }}" alt="{{ $about->name }}" title="{{ $about->name }}">
        {{ $about->name }}
      </a>
      {{-- <h1 class="logo me-auto me-lg-0"><a href="{{ url('/') }}">
       
        <img src="{{ asset('default/indoaquatic/logo1.jpeg') }}" >
      </a></h1> --}}
       {{-- {{ $about->name }} --}}
      {{-- <img style="max-width: 100px;max-height:50px" src="{{ asset('default/indoaquatic/logo2.jpeg') }}" > --}}
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link {{ Request::is('/') ? 'active' : '' }}" href="{{ url('/') }}">Home</a></li>
          <a class="nav-link scrollto {{ Request::path() == 'about-us' ? 'active' : '' }}" href="{{ url('/about-us') }}">About Us</a>
          <li><a class="nav-link scrollto {{ Request::path() == 'product' ? 'active' : '' }}" href="{{ url('/product') }}">Product</a></li>
          <li><a class="nav-link scrollto {{ Request::path() == 'galleries' ? 'active' : '' }}" href="{{ url('/galleries') }}">Gallery</a></li>
          <li><a class="nav-link scrollto {{ Request::path() == 'blogs' ? 'active' : '' }}" href="{{ url('/blogs') }}">Blog</a></li>
          <li><a class="nav-link scrollto {{ Request::path() == 'contact-us' ? 'active' : '' }}" href="{{ url('/contact-us') }}">Contact Us</a></li>
          {{-- <li><a class="nav-link scrollto" href="#menu">Menu</a></li>
          <li><a class="nav-link scrollto" href="#specials">Specials</a></li>
          <li><a class="nav-link scrollto" href="#events">Events</a></li>
          <li><a class="nav-link scrollto" href="#chefs">Chefs</a></li>
          <li><a class="nav-link scrollto" href="#gallery">Gallery</a></li>
          <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li> --}}
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      {{-- <a href="#book-a-table" class="book-a-table-btn scrollto d-none d-lg-flex">Book a table</a> --}}

    </div>
  </header><!-- End Header -->


    {{-- <main> --}}
        @yield('content')
    {{-- </main> --}}


  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>{{ $about->name }}</h3>
              <h5>{{ $about->perusahaan }}</h5>
              <p>
                {{ $about->address }}<br>
                <strong>Phone:</strong> {{ $about->phone }}<br>
                <strong>Email:</strong> {{ $about->email }}<br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/') }}">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/about-us') }}">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/product') }}">Product</a></a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/galleries') }}">Gallery</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/blogs') }}">Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/contact-us') }}">Contact Us</a></li>
            </ul>
          </div>
              {{-- <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div> --}}

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>{{ $about->perusahaan }}</span></strong>. All Rights Reserved
      </div>
      {{-- <div class="credits"> --}}
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/restaurantly-restaurant-template/ -->
        {{-- Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div> --}}
    </div>
  </footer><!-- End Footer -->
  <a href="https://api.whatsapp.com/send/?phone=%{{$about->phone}}&text=Hello%2C%20I%20have%20a%20question.%20" target="_blank" class="floatChat">
    <img src="{{ asset('themeaqua/assets/img/wa2.png') }}" alt="whatsapp" width="30">
    <span>Contact Us</span>
</a>

  {{-- <div id="preloader"></div> --}}
  {{-- <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> --}}
  {{-- <button class="floatChat"><img src="{{ asset('themeaqua/assets/img/wa2.png') }}" alt="whatsapp" width="30"><span>Contact Us</span></button> --}}
  <!-- Vendor JS Files -->
  <script src="{{ asset('themeaqua/assets/vendor/aos/aos.js') }}"></script>
  <script src="{{ asset('themeaqua/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('themeaqua/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
  <script src="{{ asset('themeaqua/assets/vendor/isotope-layout/isotope.pkgd.min.js') }}"></script>
  <script src="{{ asset('themeaqua/assets/vendor/php-email-form/validate.js') }}"></script>
  <script src="{{ asset('themeaqua/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>

  <!-- Template Main JS File -->
  <script src="{{ asset('themeaqua/assets/js/main.js') }}"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>  
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
</body>
<script>
  $(document).ready(function() {

    $("#owl-carousel").owlCarousel({
            loop: true,
            margin: 30,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true
                },
                600: {
                    items: 2,
                    nav: false
                },
                1000: {
                    items: 3,
                    nav: true,
                    loop: false
                }
            }
        });

        $("#gallery-carousel").owlCarousel({
            loop:true,
            margin:10,
            responsiveClass:true,
            responsive:{
                0:{
                    items:1,
                    nav:true
                },
                600:{
                    items:3,
                    nav:false
                },
                1000:{
                    items:5,
                    nav:true,
                    loop:false
                }
            }
        });

        $('.carousel-control-prev, .carousel-control-next').hover(function(){
          $(this).css('opacity', '0.8');
      }, function(){
          $(this).css('opacity', '1');
      });

});

</script>
</html>
