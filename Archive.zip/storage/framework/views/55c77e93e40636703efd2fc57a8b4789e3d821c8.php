<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($about->name); ?> - <?php echo e($about->sub); ?></title>
    <!-- Tambahkan stylesheet atau CDN apapun yang Anda perlukan -->
    <meta content="<?php echo e($about->description); ?>" name="description">
    <meta content="<?php echo e($about->keywords); ?>" name="keywords">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicons -->
    <link href="<?php echo e(asset($about->favicon)); ?>" rel="icon">
    <link href="<?php echo e(asset($about->favicon)); ?>" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('themeaqua/assets/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themeaqua/assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themeaqua/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themeaqua/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themeaqua/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themeaqua/assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themeaqua/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="<?php echo e(asset('themeaqua/assets/css/style.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <!-- =======================================================
    * Template Name: Restaurantly - v3.1.0
    * Template URL: https://bootstrapmade.com/restaurantly-restaurant-template/
    * Author: BootstrapMade.com
    * License: https://bootstrapmade.com/license/
    ======================================================== -->
    
</head>
<body>
  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-center justify-content-md-between">

      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-phone d-flex align-items-center"><span><?php echo e($about->phone); ?></span></i>
        <i class="bi bi-clock d-flex align-items-center ms-4"><span> <?php echo e($about->email); ?></span></i>
      </div>

      
    </div>
  </div>

  <!-- ======= Header ======= -->
  
  <header id="header" class="fixed-top d-flex align-items-cente">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-lg-between">
      <a href="<?php echo e(url('/')); ?>" class="logo me-auto me-lg-0" >
        <img class="Sirv" src="<?php echo e(asset($about->logo)); ?>" alt="<?php echo e($about->name); ?>" title="<?php echo e($about->name); ?>">
        <?php echo e($about->name); ?>

      </a>
      
       
      
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
          <a class="nav-link scrollto <?php echo e(Request::path() == 'about-us' ? 'active' : ''); ?>" href="<?php echo e(url('/about-us')); ?>">About Us</a>
          <li><a class="nav-link scrollto <?php echo e(Request::path() == 'product' ? 'active' : ''); ?>" href="<?php echo e(url('/product')); ?>">Product</a></li>
          <li><a class="nav-link scrollto <?php echo e(Request::path() == 'galleries' ? 'active' : ''); ?>" href="<?php echo e(url('/galleries')); ?>">Gallery</a></li>
          <li><a class="nav-link scrollto <?php echo e(Request::path() == 'blogs' ? 'active' : ''); ?>" href="<?php echo e(url('/blogs')); ?>">Blog</a></li>
          <li><a class="nav-link scrollto <?php echo e(Request::path() == 'contact-us' ? 'active' : ''); ?>" href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
          
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      

    </div>
  </header><!-- End Header -->


    
        <?php echo $__env->yieldContent('content'); ?>
    


  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3><?php echo e($about->name); ?></h3>
              <h5><?php echo e($about->perusahaan); ?></h5>
              <p>
                <?php echo e($about->address); ?><br>
                <strong>Phone:</strong> <?php echo e($about->phone); ?><br>
                <strong>Email:</strong> <?php echo e($about->email); ?><br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(url('/about-us')); ?>">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(url('/product')); ?>">Product</a></a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(url('/galleries')); ?>">Gallery</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(url('/blogs')); ?>">Blog</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
            </ul>
          </div>
              

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span><?php echo e($about->perusahaan); ?></span></strong>. All Rights Reserved
      </div>
      
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/restaurantly-restaurant-template/ -->
        
    </div>
  </footer><!-- End Footer -->
  <a href="https://api.whatsapp.com/send/?phone=%<?php echo e($about->phone); ?>&text=Hello%2C%20I%20have%20a%20question.%20" target="_blank" class="floatChat">
    <img src="<?php echo e(asset('themeaqua/assets/img/wa2.png')); ?>" alt="whatsapp" width="30">
    <span>Contact Us</span>
</a>

  
  
  
  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('themeaqua/assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('themeaqua/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themeaqua/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themeaqua/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('themeaqua/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('themeaqua/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('themeaqua/assets/js/main.js')); ?>"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>  
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
</body>
<script>
  $(document).ready(function() {

    $("#owl-carousel").owlCarousel({
            loop: true,
            margin: 30,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true
                },
                600: {
                    items: 2,
                    nav: false
                },
                1000: {
                    items: 3,
                    nav: true,
                    loop: false
                }
            }
        });

        $("#gallery-carousel").owlCarousel({
            loop:true,
            margin:10,
            responsiveClass:true,
            responsive:{
                0:{
                    items:1,
                    nav:true
                },
                600:{
                    items:3,
                    nav:false
                },
                1000:{
                    items:5,
                    nav:true,
                    loop:false
                }
            }
        });

        $('.carousel-control-prev, .carousel-control-next').hover(function(){
          $(this).css('opacity', '0.8');
      }, function(){
          $(this).css('opacity', '1');
      });

});

</script>
</html>
<?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/layouts/home.blade.php ENDPATH**/ ?>