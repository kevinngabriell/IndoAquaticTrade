
<h1 align="center">Aquatic Trade</h1>
<p align="center">Company Profile PT. NIAGA LIMA SAMUDRA</p>

## Installation

```sh
$ git clone https://github.com/kingkinfajarr/company-profile.git
$ cd company-profile
$ composer install
$ npm install
$ chance .env.example to .env
$ chance setting to database
$ generate key : php artisan key:generate
$ call to active the storage : php artisan storage:link
$ call action to Migrate Database & Seeder : php artisan migrate --seed
$ start server : php artisan serve
```
## How to login to Dashboard
  - go to {url}/login
  - fill email : admin@admin.com
  - fill password : admin123
