<?php

namespace App\Http\Controllers;

use App\Models\About;
use App\Models\Blog;
use App\Models\Gallery;
use App\Models\Profil;
use App\Models\Hero;
use App\Models\Portofolio;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {   
        $about = About::first();
        $hero = Hero::first();
        $product = Portofolio::all();
        $gallery = Gallery::all();
        $blog = Blog::all();
        return view('aquatic.home',
        compact('about','product','gallery','hero','blog')
    );
    }

    // aboutus
    public function aboutus(){
        $about = About::first();
        $profile = Profil::first();
        return view('aquatic.aboutus',
        compact('about','profile')
    );
    }

    //product
    public function product(){
        $about = About::first();
        $product = Portofolio::all();
        return view('aquatic.product',
        compact('about','product')
    );
    }

    // galleries
    public function galleries(){
        $about = About::first();
        $gallery = Gallery::all();
        return view('aquatic.galleries',
        compact('about','gallery')
    );
    }

    //contactus
    public function contactus(){
        $about = About::first();

        return view('aquatic.contactus',
        compact('about')
    );
    }

    public function blogdetail($slug){
        $about = About::first();
        $blog = Blog::where('slug',$slug)->first();
        return view('aquatic.blog_detail',
        compact('about','blog'));
    }

    public function blog(){
        $about = About::first();
        $blog = Blog::all();
        return view('aquatic.blog',
        compact('about','blog'));
    }

}
