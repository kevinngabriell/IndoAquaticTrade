<!-- resources/views/home.blade.php -->



<?php $__env->startSection('content'); ?>
 
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative text-center text-lg-start" data-aos="zoom-in" data-aos-delay="100">
      <div class="row">
        <div class="col-lg-8">
          <h1>Welcome to <span><?php echo e($about->name); ?></span></h1>
          <h2><?php echo e($about->sub); ?></h2>
          <h2><?php echo e($about->taglines); ?></h2>

          <div class="btns">
            <a href="#menu" class="btn-menu animated fadeInUp scrollto">Our Menu</a>
            
          </div>
        </div>
        <div class="col-lg-4 d-flex align-items-center justify-content-center position-relative" data-aos="zoom-in" data-aos-delay="200">
          <a href="https://www.youtube.com/watch?v=GlrxcuEDyF8" class="glightbox play-btn"></a>
        </div>

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="100">
            <div class="about-img">
              <img src="<?php echo e(asset('themeaqua/assets/img/udang.jpeg')); ?> " alt="">
            </div>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h3><?php echo e($hero->title); ?></h3>
            
            
            <ul class="list-unstyled">
              <?php
                // Split the description into individual items
                $items = explode('', $hero->description);
            
                // Remove the empty first element
                array_shift($items);
            
                // Iterate through the items
                foreach ($items as $item) {
                    // Output the list item HTML structure
                    echo '<li class="d-flex align-items-center">';
                    echo '<i class="bi bi-check-circle text-primary me-2"></i>';
                    echo '<span>' . trim($item) . '</span>';
                    echo '</li>';
                }
            ?>
          </ul>
          
            
            
            
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us" style="color: black !important">
      <div class="container" data-aos="fade-up">

        <div class="section-title" >
          <h2>Why Us</h2>
          <p>Why Choose Our </p>
        </div>

        <div class="row">
         
          <?php
          // Split the content into individual items
          $items = explode(PHP_EOL, $hero->why_us);

          // Iterate through the items
          for ($i = 0; $i < count($items); $i += 2) {
              // Extract title and description
              $title = trim($items[$i]);
              $description = trim($items[$i + 1]);
              
              // Output the card HTML structure
              echo '<div class="col-lg-6 mb-2">';
              echo '<div class="card" class="box" data-aos="zoom-in">';
              echo '<div class="card-body">';
              echo '<h5 class="card-title">' . $title . '</h5>';
              echo '<p class="card-text">' . $description . '</p>';
              echo '</div>';
              echo '</div>';
              echo '</div>';
          }
          ?>
      </div>
      
      

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Menu Section ======= -->
    <section id="menu" class="menu section-bg" style="background: white !important; color: black !important">
      <div class="container" data-aos="fade-up">
            
          <div class="row align-items-center">
              <div class="col-lg-6">
                  <h6 class="font-weight-semi-bold text-uppercase mb-3 text-primary">Our Products</h6>
                  <h3 class="h1 mb-4 section-title text-black">Premium Quality Seafood Products</h3>
                  <p class="text-black">Agreeseafood offers a variety of high-quality seafood products that are both delicious and sustainable. From fresh fish like yellowfin tuna and grouper to vannamei shrimp and black tiger shrimp, our products are carefully sourced from Indonesian local fishermen.</p>
                  <a href="" class="btn btn-primary mt-3 py-2 px-4" data-toggle="modal" data-target="#getAQuote">Get A Quote</a>
              </div>
              <div class="col-lg-6">
                  <div id="owl-carousel" class="owl-carousel owl-theme">
                      <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="item">
                          <div class="menu-item2 filter-starters">
                              <img src="<?php echo e(asset('storage/' . $item->foto_portofolio)); ?>" class="menu-img2" alt="<?php echo e($item->title_portofolio); ?>">
                              <div class="menu-content2">
                                  <h5 class="font-weight-bold mt-4 pb-2"><?php echo e($item->title_portofolio); ?></h5>
                              </div>
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              </div>
          </div>
      </div>
  </section>

  
    <section id="menu" class="menu section-bg" style="display: none">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Product</h2>
          <p>Check Our Product</p>
        </div>
        <div class="row align-items-center">
          <div class="col-lg-6">
              <h6 class="font-weight-semi-bold text-uppercase mb-3 text-primary">Our Products</h6>
              <h3 class="h1 mb-4 section-title text-white">Premium Quality Seafood Products</h3>
              <p class="text-white">Agreeseafood offers a variety of high-quality seafood products that are both delicious and sustainable. From fresh fish like yellowfin tuna and grouper to vannamei shrimp and black tiger shrimp, our products are carefully sourced from Indonesian local fishermen.</p>
              <a href="" class="btn btn-primary mt-3 py-2 px-4" data-toggle="modal" data-target="#getAQuote">Get A Quote</a>
          </div>
          <div class="col-lg-6">
              <div id="owl-carousel" class="owl-carousel owl-theme">
                  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="item">
                    <div class="col-lg-6 menu-item filter-starters">
                        <img src="<?php echo e(asset('storage/' . $item->foto_portofolio)); ?>" class="menu-img" alt="<?php echo e($item->title_portofolio); ?>">
                        <div class="menu-content">
                            <h5 class="font-weight-bold mt-4 pb-2"><?php echo e($item->title_portofolio); ?></h5>
                        </div>
                    </div>
                </div>
                
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
          </div>
      </div>
      
      
      
       

        <div class="row menu-container" data-aos="fade-up" data-aos-delay="200" style="display: none">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 menu-item filter-starters">
                <img src="<?php echo e(asset('storage/' . $item->foto_portofolio)); ?>" class="menu-img" alt="">
                <div class="menu-content">
                  <a href="#"><?php echo e($item->title_portofolio); ?></a>
                </div>
                <div class="menu-ingredients">
                    <?php echo e($item->sub_title); ?>

                </div>
              </div>
    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          

        </div>

      </div>
    </section><!-- End Menu Section -->

    

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery" style="background: #032f60 !important; color: white !important">

      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Gallery</h2>
          <p>Some photos from Our Gallery</p>
        </div>
      </div>

      <div class="row m-0 mt-4">
        <div class="col-12">
         
    
    
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <?php $active = true; ?>
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($active ? 'active' : ''); ?>">
                    <img src="<?php echo e(asset('storage/' . $item->foto_gallery)); ?>" class="d-block mx-auto img-fluid main-image" alt="<?php echo e($item->foto_gallery); ?>" style="max-height: calc(100vh - 80px) !important;object-fit: contain !important;width: 100% !important;vertical-align: middle !important; ">
                </div>
                <?php $active = false; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <ol class="carousel-indicators2">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($key == 0 ? 'active' : ''); ?>">
                    <img src="<?php echo e(asset('storage/' . $item->foto_gallery)); ?>" class="d-block w-100 carousel-thumbnail" alt="<?php echo e($item->foto_gallery); ?>">
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only"></span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only"></span>
        </a>
    </div>
    
    
</div>
</div>
    
    
      
    

      <div class="container-fluid" data-aos="fade-up" data-aos-delay="100" style="display: none">

        <div class="row g-0">
          <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-lg-3 col-md-4">
              <div class="gallery-item">
                <a href="<?php echo e(asset('storage/' . $item->foto_gallery)); ?>" class="gallery-lightbox" data-gall="gallery-item">
                  <img src="<?php echo e(asset('storage/' . $item->foto_gallery)); ?>" alt="" class="img-fluid">
                </a>
              </div>
            </div>
      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>Empty</p>
        <?php endif; ?>

        </div>

      </div>
    </section>
    <!-- End Gallery Section -->

    <!-- ======= Events Section ======= -->
    <section id="events2" class="events2" style="background: white !important; color: black !important">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Blog</h2>
          <p>Our Blog</p>
        </div>
        <div class="events-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">
              <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="swiper-slide">
                      <div class="row event-item">
                          <div class="col-lg-6">
                              <img src="<?php echo e(asset('storage/' . $item->image_blog)); ?>" class="img-fluid" alt="Blog Image">
                          </div>
                          <div class="col-lg-6 pt-4 pt-lg-0 content">
                            <h3><?php echo e($item->title); ?></h3>
                            <p class="fst-italic"><?php echo e(substr(strip_tags($item->content), 0, 700)); ?></p>
                            <a href="<?php echo e(route('blog.show', $item->slug)); ?>" class="btn btn-primary">Read more</a>
                        </div>
                      </div>
                  </div><!-- End testimonial item -->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <div class="swiper-slide">
                      <p>No blog posts available.</p>
                  </div><!-- End testimonial item -->
              <?php endif; ?>
          </div>
          <div class="swiper-pagination"></div>
      </div>
      

      </div>
    </section><!-- End Events Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p>Contact Us</p>
        </div>
      </div>

      <div data-aos="fade-up">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15864.689555233223!2d106.59650390554741!3d-6.240997478838428!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fd9ff11c86b1%3A0xe848c609ea81d6c9!2sRuko%20Solvang%20Arcade!5e0!3m2!1sid!2sid!4v1712827742674!5m2!1sid!2sid" style="border:0; width: 100%; height: 350px;" frameborder="0" allowfullscreen></iframe>
       </div>

      <div class="container" data-aos="fade-up">

        <div class="row mt-5">

          <div class="col-lg-4">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p><?php echo e($about->address); ?></p>
              </div>

              <div class="open-hours">
                <i class="bi bi-clock"></i>
                <h4>Open Hours:</h4>
                <p>
                  <?php echo ($about->open_hours); ?>

                </p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p><?php echo e($about->email); ?></p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p><?php echo e($about->phone); ?></p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0">

            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="8" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->
    <!-- End Contact Section -->

  </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/aquatic/home.blade.php ENDPATH**/ ?>