@extends('layouts.home')

@section('content')
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Products</h2>
          <ol>
            <li><a href="{{ url('/') }}">Home</a></li>
            <li>Products</li>
          </ol>
        </div>

      </div>
    </section>

    <section id="menu" class="menu section-bg">
        <div class="container" data-aos="fade-up">
  
          <div class="section-title">
            <h2>Products</h2>
            <p>Check Our Products</p>
          </div>
  
  
          <div class="row menu-container" data-aos="fade-up" data-aos-delay="200">
            @foreach ($product as $item)
            <div class="col-lg-6 menu-item filter-starters">
                <img src="{{ asset('storage/' . $item->foto_portofolio) }}" class="menu-img" alt="">
                <div class="menu-content">
                  <a href="#">{{ $item->title_portofolio }}</a>
                </div>
                <div class="menu-ingredients">
                    {{ $item->sub_title }}
                </div>
              </div>
    
            @endforeach
            
  
            
  
           
          </div>
  
        </div>
    </section>
    

    


  </main><!-- End #main -->

@endsection
