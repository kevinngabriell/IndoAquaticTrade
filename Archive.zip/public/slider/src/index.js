

import './assets/sass/index.scss';


const $ = require('jquery');
window.$ = $;
window.jQuery = $;

require('./assets/js/jquery-isystkSlider.js');
require('./assets/js/jquery-isystkOverlay.js');
require('./assets/js/jquery-isystkMovie.js');
require('./assets/js/jquery-zoomSlider.js');
require('./assets/js/common.js');
