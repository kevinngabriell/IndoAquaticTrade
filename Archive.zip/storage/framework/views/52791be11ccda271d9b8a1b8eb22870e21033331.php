<?php $__env->startSection('content'); ?>
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Products</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li>Products</li>
          </ol>
        </div>

      </div>
    </section>

    <section id="menu" class="menu section-bg">
        <div class="container" data-aos="fade-up">
  
          <div class="section-title">
            <h2>Products</h2>
            <p>Check Our Products</p>
          </div>
  
  
          <div class="row menu-container" data-aos="fade-up" data-aos-delay="200">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 menu-item filter-starters">
                <img src="<?php echo e(asset('storage/' . $item->foto_portofolio)); ?>" class="menu-img" alt="">
                <div class="menu-content">
                  <a href="#"><?php echo e($item->title_portofolio); ?></a>
                </div>
                <div class="menu-ingredients">
                    <?php echo e($item->sub_title); ?>

                </div>
              </div>
    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
  
            
  
           
          </div>
  
        </div>
    </section>
    

    


  </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/aquatic/product.blade.php ENDPATH**/ ?>