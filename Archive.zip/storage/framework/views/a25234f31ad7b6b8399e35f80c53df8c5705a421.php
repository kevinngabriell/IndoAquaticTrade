<!-- resources/views/home.blade.php -->



<?php $__env->startSection('content'); ?>
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>About Us</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li>About Us</li>
          </ol>
        </div>

      </div>
    </section>

    <section class="inner-page">
      <div class="container">
        <div class="py-12">
          <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
              <div class=" overflow-hidden shadow-xl sm:rounded-lg p-5">
                  <h2>About Us</h2>
                  <p><strong>About Us:</strong> <?php echo e($profile->sejarah); ?></p>
                  <p><strong>Vision:</strong> <?php echo e($profile->visi_misi); ?></p>
                  <p><strong>Mission:</strong></p>
                  <ul>
                      <?php
                          $profilLines = explode(PHP_EOL, $profile->profil);
                      ?>
                      <?php $__currentLoopData = $profilLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($line); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          </div>
      </div>
      
      </div>
    </section>

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/aquatic/aboutus.blade.php ENDPATH**/ ?>