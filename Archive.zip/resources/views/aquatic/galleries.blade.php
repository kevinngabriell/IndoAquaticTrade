@extends('layouts.home')

@section('content')
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Galleries</h2>
          <ol>
            <li><a href="{{ url('/') }}">Home</a></li>
            <li>Galleries</li>
          </ol>
        </div>

      </div>
    </section>

      <!-- ======= Gallery Section ======= -->
      <section id="gallery" class="gallery">

        <div class="container" data-aos="fade-up">
          <div class="section-title">
            <h2>Gallery</h2>
            <p>Some photos from Our Gallery</p>
          </div>
        </div>
  
        <div class="container-fluid" data-aos="fade-up" data-aos-delay="100">
  
          <div class="row g-0">
            @forelse ($gallery as $item)
            <div class="col-lg-3 col-md-4">
                <div class="gallery-item">
                  <a href="{{ asset('storage/' . $item->foto_gallery) }}" class="gallery-lightbox" data-gall="gallery-item">
                    <img src="{{ asset('storage/' . $item->foto_gallery) }}" alt="" class="img-fluid">
                  </a>
                </div>
              </div>
         
          @empty
            <p>Empty</p>
          @endforelse
  
          </div>
  
        </div>
      </section><!-- End Gallery Section -->

    

    


  </main><!-- End #main -->

@endsection
