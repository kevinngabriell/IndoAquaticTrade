<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/trix.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('js/trix.js')); ?>"></script>
  </head>

  <style>
    trix-toolbar [data-trix-button-group="file-tools"] {
      display: none;
    }
  </style>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Edit Profil')); ?>

      </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-5">
            <form action="<?php echo e(route('hero.update', $hero->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>
              <div class="w-full">
                <div class="title">
                  <p>Title</p>
                  <input type="text" required class="w-full" name="title" value="<?php echo e($hero->title); ?>">
                </div>
                <div class="description mt-5">
                  <p>Description</p>
                  <input id="description" type="hidden" name="description">

                  <trix-editor input="description" class="mb-3 h-56"><?php echo e($hero->description); ?></trix-editor>
                </div>
                <div class="description mt-5">
                  <p>Why Us</p>
                  <input id="why_us" type="hidden" name="why_us">
                  <trix-editor input="why_us" class="mb-3 h-56"><?php echo e($hero->why_us); ?></trix-editor>
                </div>
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" type="submit">
                  Update
                </button>
              </div>
            </form>
          </div>
      </div>
  </div>
  <script>
    document.addEventListener('trix-file-accept', function(e){
      e.preventDefault();
    })
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/hero/edit.blade.php ENDPATH**/ ?>