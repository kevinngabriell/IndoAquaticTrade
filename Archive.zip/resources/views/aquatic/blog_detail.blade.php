<!-- resources/views/home.blade.php -->

@extends('layouts.home')

@section('content')
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Blog</h2>
          <ol>
            <li><a href="{{ url('/') }}">Home</a></li>
            <li ><a href="{{ url('/blogs') }}">Blog</a> </li>
            <li>{{ $blog->title }}</li>
          </ol>
        </div>

      </div>
    </section>

    <section class="inner-page">
      <div class="container">
        <div class="py-12">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <img src="{{ asset('storage/' . $blog->image_blog) }}" class="img-fluid" width="200" alt="Blog Image">
                </div>
                {!! $blog->content !!}
            </div>
          
      </div>
      
      </div>
    </section>

  </main><!-- End #main -->

@endsection
