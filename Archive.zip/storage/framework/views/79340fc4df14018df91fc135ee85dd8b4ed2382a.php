<!-- resources/views/home.blade.php -->



<?php $__env->startSection('content'); ?>
 
<main id="main">
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Blog</h2>
          <ol>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li>Blog</li>
          </ol>
        </div>

      </div>
    </section>

    <section id="events" class="events">
        <div class="container" data-aos="fade-up">
  
          <div class="section-title">
            <h2>Blog</h2>
            <p>Our Blog</p>
          </div>
          <div class="events-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="swiper-slide">
                        <div class="row event-item">
                            <div class="col-lg-6">
                                <img src="<?php echo e(asset('storage/' . $item->image_blog)); ?>" class="img-fluid" alt="Blog Image">
                            </div>
                            <div class="col-lg-6 pt-4 pt-lg-0 content">
                              <h3><?php echo e($item->title); ?></h3>
                              <p class="fst-italic"><?php echo e(substr(strip_tags($item->content), 0, 700)); ?></p>
                              <a href="<?php echo e(route('blog.show', $item->slug)); ?>" class="btn btn-primary">Read more</a>
                          </div>
                        </div>
                    </div><!-- End testimonial item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="swiper-slide">
                        <p>No blog posts available.</p>
                    </div><!-- End testimonial item -->
                <?php endif; ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
        
  
        </div>
      </section><!-- End Events Section -->

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itki-macbookpro/Documents/project/compro/company-profile/resources/views/aquatic/blog.blade.php ENDPATH**/ ?>